﻿var designWidth, designHeight;
var screenWidth = 0, screenHeight = 0;

var $ = function (id) {
    return "string" == typeof id ? document.getElementById(id) : id;
};

var $$ = function (p, e) {
    return p.getElementsByTagName(e);
};

//坐标类
function Point(x, y) {
    this.x = x;
    this.y = y;
    this.isEqual = function (value) {
        if (this.x != value.x) {
            return false;
        } else if (this.y != value.y) {
            return false;
        } else {
            return true;
        }
    };
    this.set = function (x, y) {
        this.x = x;
        this.y = y;
    }
    this.assign = function (value) {
        this.x = value.x;
        this.y = value.y;
    };
    this.clone = function () {
        var result = new Point(0, 0);
        result.assign(this);
        return result;
    };
}

//矩形类
function Rect(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w; //宽度
    this.h = h; //高度
    this.right = function () {
        return this.x + this.w;
    }
    this.bottom = function () {
        return this.y + this.h;
    }
    this.set = function (x, y, w, h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    };
    this.getCenter = function () {
        return new Point(this.x + parseInt(this.w / 2), this.y + parseInt(this.h / 2));
    };
    //复制类数据
    this.assign = function (value) {
        this.x = value.x;
        this.y = value.y;
        this.w = value.w;
        this.h = value.h;
    }
    //克隆新类
    this.clone = function () {
        var result = new Rect(0, 0, 0, 0);
        result.assign(this);
        return result;
    }
};

function isEmpty(object) {
    if (typeof (object) == "undefined") {
        return true;
    } else if (object == null) {
        return true;
    }
    return false;
}

function setDivSize(div, w, h) {
    div.style.width = w + "px";
    div.style.height = h + "px";
}

function setDivPos(div, x, y) {
    div.style.left = x + "px";
    div.style.top = y + "px";
}

function setDivDesign(div, rect) {
    var r = rect.clone();
    r.x = parseInt((screenWidth / designWidth) * r.x);
    r.w = parseInt((screenWidth / designWidth) * r.w);
    r.y = parseInt((screenHeight / designHeight) * r.y);
    r.h = parseInt((screenHeight / designHeight) * r.h);
    setDivRect(div, r);
}

//调整矩形宽度优先
function adjRectW(r) {
    r.x = parseInt((screenWidth / designWidth) * r.x);
    r.w = parseInt((screenWidth / designWidth) * r.w);
    r.y = parseInt((screenWidth / designWidth) * r.y);
    r.h = parseInt((screenWidth / designWidth) * r.h);
}

function setDivRect(div, rect) {
    setDivPos(div, rect.x, rect.y);
    setDivSize(div, rect.w, rect.h);
}

function initDesign(fullScreenDiv, designFullScreenW, designFullScreenH) {
    designWidth = designFullScreenW;
    designHeight = designFullScreenH;
    screenWidth = getDivWidth(fullScreenDiv);
    screenHeight = getDivHeight(fullScreenDiv);
}

function getDivWidth(div) {
    return div.offsetWidth;
}

function getDivHeight(div) {
    return div.offsetHeight;
}

function getDivSize(div) {
    return new Point(getDivWidth(div), getDivHeight(div));
}

function getDivPos(div) {
    return new Point(div.offsetLeft, div.offsetTop);
}

function getDivRect(div) {
    return new Rect(getDivPos(div).x, getDivPos(div).y, getDivWidth(div), getDivHeight(div));
}

var isAndroid = false;
var isIPad = false;
var isIPhone = false;
var isWeixin = false;
function getUserAgentType() {
    u = navigator.userAgent.toLocaleLowerCase();
    isAndroid = (u.indexOf("android") > -1);
    isIPad = u.indexOf("ipad") >= 0;
    isIPhone = (navigator.platform.indexOf("iPhone") != -1) || (navigator.platform.indexOf("iPod") != -1);
    isWeixin = u.indexOf("micromessenger") >= 0;
}

//获取url参数
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)
        return unescape(r[2]);
    return null;
}

function getOs() {
    var OsObject = "";
    if (navigator.userAgent.indexOf("MSIE") > 0) {
        return "msie";
    }
    if ((isFirefox = navigator.userAgent.indexOf("Firefox")) > 0) {
        return "firefox";
    }
    if ((isSafari = navigator.userAgent.indexOf("Safari")) > 0) {
        return "safari";
    }
    if ((isCamino = navigator.userAgent.indexOf("Camino")) > 0) {
        return "camino";
    }
    if ((isMozilla = navigator.userAgent.indexOf("Gecko/")) > 0) {
        return "gecko";
    }
    return "unknow";
}

function setDivAlpha(div, alpha) {
    alpha = Math.min(1, alpha);
    alpha = Math.max(0, alpha);
    if (getOs() == "msie") {
        div.style.filter = "Alpha(Opacity=" + parseInt(alpha * 100) + ")";
    } else {
        div.style.opacity = parseInt(alpha * 100) / 100;
    }
}

function getClientSize() {
    var result = new Point(0, 0);
    if ((document.body) && (document.body.clientWidth)) {
        result.x = document.body.clientWidth;
    }
    // 获取窗口高度
    if ((document.body) && (document.body.clientHeight)) {
        result.y = document.body.clientHeight;
    }
    // 通过深入 Document 内部对 body 进行检测，获取窗口大小
    if (document.documentElement && document.documentElement.clientHeight && document.documentElement.clientWidth) {
        result.x = document.documentElement.clientWidth;
        result.y = document.documentElement.clientHeight;
    }
    return result;
}

//启动并初始化类，带界面自适应
function TamLayout() {
    TamLayout.inst = this;
    //get root
    this.root = $("divLockRatio");
    this.divLoader = $("divLoader");
    this.loaderAlpha = 2;
    this.lockRatio = 0;
    this.designSize = new Point();
    if (isEmpty(this.root)) {
        this.root = $("divRoot");
    } else {
        this.designSize.set(getDivWidth(this.root), getDivHeight(this.root));
        this.lockRatio = this.designSize.x / this.designSize.y;
        this.root2 = $("divRoot");
    }
    this.rootSize = new Point(0, 0);
    this.onTimefragment = function () {
        var inst = TamLayout.inst;
        //loader alpha control
        if (inst.loaderAlpha > 0) {
            if (!isEmpty(inst.divLoader)) {
                setDivAlpha(inst.divLoader, inst.loaderAlpha);
            }
            inst.loaderAlpha -= 0.2;
        } else if (!isEmpty(inst.divLoader)) {
            if (inst.lockRatio > 0) {
                inst.root2.removeChild(inst.divLoader);
                inst.divLoader = null;
            }
        }
        //resize control
        var newRootSize = getDivSize(inst.root2);
        if (inst.rootSize.isEqual(newRootSize)) {
            setTimeout(inst.onTimefragment, 100);
            return;
        }
        inst.rootSize.assign(newRootSize);
        if ((inst.rootSize.x <= 0) || (inst.rootSize.y <= 0)) {
            setTimeout(inst.onTimefragment, 100);
            return;
        }
        //process lock ratio
        if (inst.lockRatio > 0) {
            if ((newRootSize.x <= 0) || (newRootSize.y <= 0)) {
                setTimeout(inst.onTimefragment, 100);
                return;
            }
            var r1 = inst.lockRatio;
            var r2 = newRootSize.x / newRootSize.y;
            if (r2 >= r1) {
                r1 = Math.min(r1 * 1.2, r2);
                inst.root.style.width = parseInt(newRootSize.y * r1 + 2) + "px";
                inst.root.style.height = newRootSize.y + "px"; // "100%";
            } else {
                r1 = Math.max(r1 / 1.2, r2);
                inst.root.style.width = newRootSize.x + "px"; // "100%";
                inst.root.style.height = parseInt(newRootSize.x / r1 + 2) + "px";
            }
        }

        inst.onResize();
        setTimeout(inst.onTimefragment, 100);
    }
    //start timer
    setTimeout(this.onTimefragment, 100);
    //layout function
    this.adjustDiv = function (div, x, y, w, h) {
        var r = new Rect(x, y, w, h);
        r.x = parseInt(getDivWidth(this.root) / this.designSize.x * r.x);
        r.w = parseInt(getDivWidth(this.root) / this.designSize.x * r.w);
        r.y = parseInt(getDivHeight(this.root) / this.designSize.y * r.y);
        r.h = parseInt(getDivHeight(this.root) / this.designSize.y * r.h);
        setDivRect(div, r);
    };
    this.adjustDivIcon = function (div, x, y, w, h) {
        // 按照长宽计算目标中心位置
        var rect = new Rect(x, y, w, h);
        var center = rect.getCenter();
        center.x = parseInt(getDivWidth(this.root) / this.designSize.x * center.x);
        center.y = parseInt(getDivHeight(this.root) / this.designSize.y * center.y);
        //计算缩放标准
        ratio = Math.min(getDivWidth(this.root) / this.designSize.x, getDivHeight(this.root) / this.designSize.y);
        // 缩放
        rect.w = parseInt(rect.w * ratio);
        rect.x = parseInt(center.x - rect.w / 2);
        rect.h = parseInt(rect.h * ratio);
        rect.y = parseInt(center.y - rect.h / 2);
        setDivRect(div, rect);
    };
    this.toBottom = function (div) {
        var rect = getDivRect(div);
        rect.y = getDivHeight(this.root) - rect.h;
        setDivRect(div, rect);
    }
    this.toTop = function (div) {
        var rect = getDivRect(div);
        rect.y = 0;
        setDivRect(div, rect);
    }
    //abstract function
    this.onResize = function () { };
};

/////////////////////////////////TamPub1改造部分/////////////////////////////////
var TDIV_Current = null;
function TDIV_C(Parent) { //Tam <DIV> Create
    TDIV_Current = document.createElement("div");
    if (Parent == null) {
        document.body.insertBefore(TDIV_Current, document.body.firstChild);
    } else Parent.appendChild(TDIV_Current);
    TDIV_Current.style.overflow = "hidden";
    TDIV_Current.style.position = "absolute";
    TDIV_Current.style.whiteSpace = "nowrap";
    TDIV_Current.style.fontFamily = "宋体";
    TDIV_Current.style.fontSize = "9pt";
    TDIV_Current.style.textAlign = "left";
    return TDIV_Current;
}
function TDIV_P(Left, Top, Width, Height) { //Tam <DIV> set Position
    var iTemp;
    if (!isEmpty(Left)) {
        iTemp = parseInt(Left);
        if ((TDIV_Current.style.pixelLeft != iTemp) || (TDIV_Current.style.left == "")) TDIV_Current.style.left = iTemp;
    }
    if (!isEmpty(Top)) {
        iTemp = parseInt(Top);
        if ((TDIV_Current.style.pixelTop != iTemp) || (TDIV_Current.style.top == "")) TDIV_Current.style.top = iTemp;
    }
    if (!isEmpty(Width)) {
        iTemp = parseInt(Width);
        if (iTemp < 0) iTemp = 0;
        if ((TDIV_Current.style.pixelWidth != iTemp) || (TDIV_Current.style.width == "")) TDIV_Current.style.width = iTemp;
    }
    if (!isEmpty(Height)) {
        iTemp = parseInt(Height);
        if (iTemp < 0) iTemp = 0;
        if ((TDIV_Current.style.pixelHeight != iTemp) || (TDIV_Current.style.height == "")) TDIV_Current.style.height = iTemp;
    }
}
function TIMG_C(parent, imgUrl) {
    var c = document.createElement("img");
    if (parent == null) {
        document.body.insertBefore(c, document.body.firstChild);
    } else parent.appendChild(c);
    c.style.position = "absolute";
    c.src = imgUrl;
    return c;
}
function TIMG_P(img, x, y, w, h) {
    if (!isEmpty(x)) img.style.left = x;
    if (!isEmpty(y)) img.style.top = y;
    if (!isEmpty(w)) img.width = w;
    if (!isEmpty(h)) img.height = h;
}






